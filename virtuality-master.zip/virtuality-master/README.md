virtuality
==========

Qt4/Qt5 widget style
